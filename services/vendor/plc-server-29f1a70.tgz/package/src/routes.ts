import { pipeline } from 'node:stream/promises'
import express from 'express'
import type { WebSocket } from 'ws'
import { createWebSocketStream } from 'ws'
import * as plc from '@did-plc/lib'
import { ServerError } from './error.js'
import { handler } from './handler.js'
import type { AppContext } from './context.js'
import { assertValidIncomingOp } from './constraints.js'
import { stringify, timingSafeStringEqual } from './util.js'
import { Outbox, OutboxError } from './sequencer/index.js'
import {
  recordAcceptedOperation,
  recordRejectedOperation,
  streamSubscribers,
} from './metrics.js'

// Once a websocket has this much data buffered, we wait for it to flush
// before sending more events. Slow consumers then apply backpressure into
// the outbox, which closes them if they fall too far behind — rather than
// buffering events in process memory without bound.
const MAX_WS_BUFFERED_BYTES = 256 * 1024
const PLC_DID_RE = /^did:plc:[a-z2-7]{24}$/

// Invalid DID methods are a common crawler input. Reject them before a
// database round trip with a response that distinguishes unsupported methods
// from unregistered PLC DIDs.
const assertPlcDid = (did: string): void => {
  if (!PLC_DID_RE.test(did)) {
    throw new ServerError(
      400,
      `Resolution of non-PLC DIDs not supported: ${did}`,
    )
  }
}

export const createRouter = (ctx: AppContext): express.Router => {
  const router = express.Router()
  streamSubscribers.add(0)

  router.get(
    '/',
    handler(async function (req, res) {
      // HTTP temporary redirect to project homepage
      res.redirect(302, 'https://web.plc.directory')
    }),
  )

  router.get(
    '/_health',
    handler(async function (req, res) {
      const { db, version } = ctx
      try {
        await db.healthCheck()
      } catch (err) {
        req.log.error(err, 'failed health check')
        return res.status(503).send({ version, error: 'Service Unavailable' })
      }
      res.send({ version })
    }),
  )

  // Export ops in the form of paginated json lines
  router.get(
    '/export',
    handler(async function (req, res) {
      const countParam =
        typeof req.query.count === 'string' ? req.query.count : undefined
      const parsedCount = countParam ? parseInt(countParam, 10) : 1000
      if (isNaN(parsedCount) || parsedCount < 1) {
        throw new ServerError(400, 'Invalid count parameter')
      }
      const count = Math.min(parsedCount, 1000)

      const afterParam =
        typeof req.query.after === 'string' ? req.query.after : undefined
      const isNumeric = afterParam && /^\d+$/.test(afterParam)

      let ops: plc.ExportedOpWithSeq[] | plc.ExportedOp[]
      if (isNumeric) {
        // after is integer seq
        const after = parseInt(afterParam, 10)
        if (isNaN(after) || after < 0) {
          throw new ServerError(400, 'Invalid after parameter')
        }
        ops = await ctx.db.exportOpsSeq(count, after)
      } else {
        // after is timestamp
        const after = afterParam ? new Date(afterParam) : undefined
        if (after !== undefined && isNaN(after.getTime())) {
          throw new ServerError(400, 'Invalid after parameter')
        }
        ops = await ctx.db.exportOps(count, after)
      }

      res.setHeader('content-type', 'application/jsonlines')
      res.status(200)
      for (let i = 0; i < ops.length; i++) {
        if (i > 0) {
          res.write('\n')
        }
        const line = JSON.stringify(ops[i])
        res.write(line)
      }
      res.end()
    }),
  )

  // Stream sequenced operations over WebSocket
  router.get(
    '/export/stream',
    handler(async function (req, _res) {
      if (!req.headers.upgrade || !req.ws) {
        throw new ServerError(426, 'upgrade required')
      }

      const cursorParam =
        typeof req.query.cursor === 'string' ? req.query.cursor : undefined
      const cursor = cursorParam ? parseInt(cursorParam, 10) : undefined
      if (cursor !== undefined && (isNaN(cursor) || cursor < 0)) {
        throw new ServerError(400, 'Invalid cursor parameter')
      }

      req.ws.handled = true
      ctx.wss.handleUpgrade(
        req,
        req.ws.socket,
        req.ws.head,
        async function (ws: WebSocket) {
          const abortController = new AbortController()
          const outbox = new Outbox(ctx.sequencer)

          streamSubscribers.add(1)
          ws.once('close', () => {
            streamSubscribers.add(-1)
            abortController.abort()
          })

          // Note: each event is sent in a separate websocket message.
          // OutboxErrors (stale cursor, consumer too slow) close the socket
          // gracefully with a reason, rather than erroring the pipeline, which
          // would abruptly terminate the socket without a close frame.
          async function* outboxEvents() {
            try {
              yield* outbox.events(cursor, abortController.signal)
            } catch (err) {
              if (err instanceof OutboxError) {
                ws.close(1000, err.message)
                return
              }
              throw err
            }
          }

          // decodeStrings: false so events are sent as text frames, not binary
          const websocket = createWebSocketStream(ws, {
            decodeStrings: false,
            writableHighWaterMark: MAX_WS_BUFFERED_BYTES,
          })

          try {
            await pipeline(outboxEvents(), stringify, websocket)
          } catch (err) {
            if (!abortController.signal.aborted) {
              req.log.error({ err }, 'error streaming events')
            }
          }
        },
      )
    }),
  )

  // Get data for a DID document
  router.get(
    '/:did',
    handler(async function (req, res) {
      const { did } = req.params
      assertPlcDid(did)
      const last = await ctx.db.lastOpForDid(did)
      if (!last) {
        throw new ServerError(404, `DID not registered: ${did}`)
      }
      const data = plc.opToData(did, last)
      if (data === null) {
        throw new ServerError(404, `DID not available: ${did}`)
      }
      const doc = await plc.formatDidDoc(data)
      res.type('application/did+ld+json')
      res.send(JSON.stringify(doc))
    }),
  )

  // Get data for a DID document
  router.get(
    '/:did/data',
    handler(async function (req, res) {
      const { did } = req.params
      assertPlcDid(did)
      const last = await ctx.db.lastOpForDid(did)
      if (!last) {
        throw new ServerError(404, `DID not registered: ${did}`)
      }
      const data = plc.opToData(did, last)
      if (data === null) {
        throw new ServerError(404, `DID not available: ${did}`)
      }
      res.json(data)
    }),
  )

  // Get operation log for a DID
  router.get(
    '/:did/log',
    handler(async function (req, res) {
      const { did } = req.params
      assertPlcDid(did)
      const log = await ctx.db.opsForDid(did)
      if (log.length === 0) {
        throw new ServerError(404, `DID not registered: ${did}`)
      }
      res.json(log)
    }),
  )

  // Get operation log for a DID
  router.get(
    '/:did/log/audit',
    handler(async function (req, res) {
      const { did } = req.params
      assertPlcDid(did)
      const ops = await ctx.db.indexedOpsForDid(did, true)
      if (ops.length === 0) {
        throw new ServerError(404, `DID not registered: ${did}`)
      }
      const log = ops.map((op) => ({
        ...op,
        cid: op.cid.toString(),
        createdAt: op.createdAt.toISOString(),
      }))

      res.json(log)
    }),
  )

  // Get the most recent operation in the log for a DID
  router.get(
    '/:did/log/last',
    handler(async function (req, res) {
      const { did } = req.params
      assertPlcDid(did)
      const last = await ctx.db.lastOpForDid(did)
      if (!last) {
        throw new ServerError(404, `DID not registered: ${did}`)
      }
      res.json(last)
    }),
  )

  // Update or create a DID doc
  router.post(
    '/:did',
    handler(async function (req, res) {
      const { did } = req.params
      const op = req.body
      try {
        assertValidIncomingOp(op)
        await ctx.db.validateAndAddOp(did, op, new Date())
      } catch (err) {
        recordRejectedOperation(err)
        throw err
      }
      recordAcceptedOperation(op)
      res.sendStatus(200)
    }),
  )

  // We only have one admin endpoint, so an auth middleware would probably be overkill
  router.post(
    '/admin/removeInvalidOps',
    handler(async function (req, res) {
      const { adminSecret, did, cid } = req.body

      // admin auth
      if (!ctx.adminSecret) {
        throw new ServerError(401, 'admin secret has not been configured')
      }
      if (!timingSafeStringEqual(adminSecret, ctx.adminSecret)) {
        throw new ServerError(401, 'invalid admin secret')
      }

      const removedOps = await ctx.db.removeInvalidOps(did, cid)
      res.json(removedOps)
    }),
  )

  return router
}

export default createRouter
