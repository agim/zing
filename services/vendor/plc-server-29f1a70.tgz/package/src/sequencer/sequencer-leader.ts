import { Leader } from '../db/leader.js'
import type PgDatabase from '../db/index.js'
import { sql } from 'kysely'
import { PLC_SEQ_SEQUENCE } from '../db/types.js'
import { leaderLogger as log } from '../logger.js'
import { wait, jitter } from '@atproto/common'
import { sequencerSequence } from '../metrics.js'

const SEQUENCER_LEADER_ID = 1100

export type SequencerLeaderOptions = {
  pollIntervalMs?: number
}

export class SequencerLeader {
  leader: Leader
  destroyed = false
  pollIntervalMs: number

  constructor(
    public db: PgDatabase,
    opts: SequencerLeaderOptions = {},
  ) {
    this.leader = new Leader(SEQUENCER_LEADER_ID, db)
    this.pollIntervalMs = opts.pollIntervalMs ?? 50
  }

  get isLeader() {
    return !!this.leader.session
  }

  async run() {
    while (!this.destroyed) {
      try {
        const { ran } = await this.leader.run(async ({ signal }) => {
          // Poll frequently
          while (!(signal.aborted || this.destroyed)) {
            await this.sequenceOutgoing()
            await wait(this.pollIntervalMs)
          }
        })
        if (ran && !this.destroyed) {
          // should be unreachable
          throw new Error(
            'Sequencer leader completed, but should be persistent',
          )
        }
      } catch (err) {
        log.error({ err }, 'sequence leader errored')
      } finally {
        if (!this.destroyed) {
          // retry, with jitter
          await wait(1000 + jitter(500))
        }
      }
    }
  }

  async sequenceOutgoing(): Promise<void> {
    // Assign seq numbers to all pending events in insertion order
    await this.db.db
      .updateTable('operations')
      .from((qb) =>
        qb
          .selectFrom('operations')
          .select([
            'did as update_did',
            'cid as update_cid',
            sql<number>`nextval(${sql.literal(PLC_SEQ_SEQUENCE)})`.as(
              'update_seq',
            ),
          ])
          .where('seq', 'is', null)
          .orderBy('createdAt', 'asc')
          .orderBy(sql`cid COLLATE "C"`, 'asc')
          .limit(1000) // Prevent too much getting sequenced in one go - maybe needs tweaking?
          .as('update'),
      )
      .set({
        seq: sql`update_seq::bigint`,
      })
      .whereRef('did', '=', 'update_did')
      .whereRef('cid', '=', 'update_cid')
      .execute()
  }

  async lastSeq(): Promise<number> {
    const res = await this.db.db
      .selectFrom('operations')
      .select('seq')
      .where('seq', 'is not', null)
      .orderBy('seq', 'desc')
      .limit(1)
      .executeTakeFirst()
    const seq = res?.seq ?? 0
    if (this.isLeader && !this.destroyed) {
      sequencerSequence.record(seq)
    }
    return seq
  }

  destroy(): void {
    this.destroyed = true
    this.leader.destroy()
  }
}
